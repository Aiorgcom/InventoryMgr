
import React from 'react';
import { Package, TrendingUp, AlertTriangle, IndianRupee, Plus } from 'lucide-react';
import { Link } from 'react-router-dom';
import StatCard from '@/components/StatCard';
import { useIsMobile } from '@/hooks/use-mobile';
import { useProducts } from '@/hooks/useProducts';

const Dashboard = () => {
  const isMobile = useIsMobile();
  const { products, categories, loading } = useProducts();

  // Get products with category names and calculate real-time stats
  const productsWithCategories = products.map(product => {
    const category = categories.find(cat => cat.id === product.category_id);
    return {
      ...product,
      category: category?.name || 'Unknown',
      lowStock: product.quantity <= (product.low_stock_threshold || 5)
    };
  });

  const lowStockProducts = productsWithCategories.filter(p => p.lowStock);
  const totalValue = products.reduce((sum, p) => sum + (p.price * p.quantity), 0);

  const stats = [
    {
      title: 'Total Products',
      value: products.length.toString(),
      icon: Package,
      color: 'bg-blue-500',
      trend: { value: 12, isPositive: true }
    },
    {
      title: 'Low Stock Items',
      value: lowStockProducts.length.toString(),
      icon: AlertTriangle,
      color: 'bg-red-500',
      trend: { value: 3, isPositive: false }
    },
    {
      title: 'Stock Value',
      value: `₹${totalValue.toLocaleString()}`,
      icon: IndianRupee,
      color: 'bg-green-500',
      trend: { value: 8, isPositive: true }
    },
    {
      title: 'Categories', 
      value: categories.length.toString(),
      icon: TrendingUp,
      color: 'bg-purple-500',
      trend: { value: 15, isPositive: true }
    }
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Dashboard</h1>
          <p className="text-gray-600">Welcome back! Here's your store overview.</p>
        </div>
        
        <Link
          to="/add"
          className="bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors duration-200 shadow-sm"
        >
          <Plus className="w-4 h-4" />
          <span className="hidden sm:inline">Add Product</span>
        </Link>
      </div>

      {/* Stats Grid */}
      <div className={`grid gap-4 ${isMobile ? 'grid-cols-2' : 'grid-cols-4'}`}>
        {stats.map((stat, index) => (
          <StatCard
            key={index}
            title={stat.title}
            value={stat.value}
            icon={stat.icon}
            color={stat.color}
            trend={stat.trend}
          />
        ))}
      </div>

      {/* Quick Actions & Low Stock Alert */}
      <div className={`grid gap-6 ${isMobile ? 'grid-cols-1' : 'grid-cols-2'}`}>
        {/* Quick Actions */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h2>
          <div className="space-y-3">
            <Link
              to="/add"
              className="flex items-center space-x-3 p-3 bg-orange-50 hover:bg-orange-100 rounded-lg transition-colors duration-200"
            >
              <Plus className="w-5 h-5 text-orange-600" />
              <span className="font-medium text-orange-600">Add New Product</span>
            </Link>
            
            <Link
              to="/inventory"
              className="flex items-center space-x-3 p-3 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors duration-200"
            >
              <Package className="w-5 h-5 text-blue-600" />
              <span className="font-medium text-blue-600">View All Products</span>
            </Link>
            
            <Link
              to="/reports"
              className="flex items-center space-x-3 p-3 bg-green-50 hover:bg-green-100 rounded-lg transition-colors duration-200"
            >
              <TrendingUp className="w-5 h-5 text-green-600" />
              <span className="font-medium text-green-600">View Reports</span>
            </Link>
          </div>
        </div>

        {/* Low Stock Alert */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center space-x-2 mb-4">
            <AlertTriangle className="w-5 h-5 text-red-500" />
            <h2 className="text-lg font-semibold text-gray-900">Low Stock Alert</h2>
          </div>
          
          <div className="space-y-3">
            {lowStockProducts.length > 0 ? (
              lowStockProducts.slice(0, 4).map((product, index) => (
                <div key={index} className="flex justify-between items-center p-3 bg-red-50 rounded-lg">
                  <span className="font-medium text-gray-900">{product.name}</span>
                  <span className="text-red-600 font-semibold text-sm">
                    {product.quantity} {product.unit} left
                  </span>
                </div>
              ))
            ) : (
              <div className="text-center py-4 text-gray-500">
                <Package className="w-8 h-8 mx-auto mb-2 text-gray-300" />
                <p>All products are well stocked!</p>
              </div>
            )}
          </div>
          
          {lowStockProducts.length > 0 && (
            <Link
              to="/inventory"
              className="block text-center mt-4 text-red-600 hover:text-red-700 font-medium"
            >
              View All Low Stock Items ({lowStockProducts.length})
            </Link>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
