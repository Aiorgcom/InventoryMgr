
import React, { useState } from 'react';
import { BarChart3, TrendingUp, Package, IndianRupee, Calendar, Download } from 'lucide-react';
import { useIsMobile } from '@/hooks/use-mobile';
import { useProducts } from '@/hooks/useProducts';

const Reports = () => {
  const isMobile = useIsMobile();
  const { products, categories, loading } = useProducts();
  const [selectedPeriod, setSelectedPeriod] = useState('monthly');

  // Calculate real-time analytics
  const productsWithCategories = products.map(product => {
    const category = categories.find(cat => cat.id === product.category_id);
    return {
      ...product,
      category: category?.name || 'Unknown',
      lowStock: product.quantity <= (product.low_stock_threshold || 5)
    };
  });

  const lowStockProducts = productsWithCategories.filter(p => p.lowStock);
  const totalValue = products.reduce((sum, p) => sum + (p.price * p.quantity), 0);

  // Calculate category-wise analytics
  const categoryAnalytics = categories.map(category => {
    const categoryProducts = productsWithCategories.filter(p => p.category === category.name);
    const categoryValue = categoryProducts.reduce((sum, p) => sum + (p.price * p.quantity), 0);
    const percentage = totalValue > 0 ? Math.round((categoryValue / totalValue) * 100) : 0;
    
    return {
      name: category.name,
      value: categoryValue,
      percentage,
      productCount: categoryProducts.length
    };
  }).filter(cat => cat.productCount > 0).sort((a, b) => b.value - a.value);

  // Get top products by value
  const topProducts = productsWithCategories
    .map(product => ({
      name: product.name,
      quantity: product.quantity,
      value: product.price * product.quantity,
      category: product.category
    }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 5);

  // Recent activity based on created_at
  const recentActivity = products
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
    .slice(0, 4)
    .map(product => ({
      action: 'Added',
      item: product.name,
      time: new Date(product.created_at).toLocaleDateString()
    }));

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-600"></div>
      </div>
    );
  }

  const StatCard = ({ title, value, icon: Icon, color, change }: any) => (
    <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
      <div className="flex items-center justify-between mb-4">
        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${color}`}>
          <Icon className="w-5 h-5 text-white" />
        </div>
        {change && (
          <span className={`text-sm font-medium ${change > 0 ? 'text-green-600' : 'text-red-600'}`}>
            {change > 0 ? '+' : ''}{change}%
          </span>
        )}
      </div>
      <h3 className="text-2xl font-bold text-gray-900 mb-1">{value}</h3>
      <p className="text-gray-600 text-sm">{title}</p>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Reports</h1>
          <p className="text-gray-600">Analytics and insights for your business</p>
        </div>
        
        <button className="bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors duration-200 shadow-sm">
          <Download className="w-4 h-4" />
          <span className="hidden sm:inline">Export</span>
        </button>
      </div>

      {/* Time Period Selector */}
      <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
        <div className="flex items-center space-x-4">
          <Calendar className="w-5 h-5 text-gray-500" />
          <span className="font-medium text-gray-700">Period:</span>
          <select 
            value={selectedPeriod}
            onChange={(e) => setSelectedPeriod(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
          >
            <option value="daily">Today</option>
            <option value="weekly">This Week</option>
            <option value="monthly">This Month</option>
          </select>
        </div>
      </div>

      {/* Key Metrics */}
      <div className={`grid gap-4 ${isMobile ? 'grid-cols-2' : 'grid-cols-4'}`}>
        <StatCard
          title="Total Products"
          value={products.length.toString()}
          icon={Package}
          color="bg-blue-500"
          change={5}
        />
        <StatCard
          title="Stock Value"
          value={`₹${totalValue.toLocaleString()}`}
          icon={IndianRupee}
          color="bg-green-500"
          change={12}
        />
        <StatCard
          title="Categories"
          value={categories.length.toString()}
          icon={TrendingUp}
          color="bg-purple-500"
          change={8}
        />
        <StatCard
          title="Low Stock Items"
          value={lowStockProducts.length.toString()}
          icon={BarChart3}
          color="bg-red-500"
          change={-3}
        />
      </div>

      {/* Charts and Analytics */}
      <div className={`grid gap-6 ${isMobile ? 'grid-cols-1' : 'grid-cols-2'}`}>
        {/* Top Categories */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h2 className="text-lg font-semibold text-gray-900 mb-6">Top Categories</h2>
          <div className="space-y-4">
            {categoryAnalytics.length > 0 ? (
              categoryAnalytics.map((category, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-medium text-gray-900">
                        {category.name} ({category.productCount} items)
                      </span>
                      <span className="text-sm text-gray-600">₹{category.value.toLocaleString()}</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-orange-500 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${category.percentage}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-gray-500 text-center py-4">No data available</p>
            )}
          </div>
        </div>

        {/* Top Products */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h2 className="text-lg font-semibold text-gray-900 mb-6">Top Selling Products</h2>
          <div className="space-y-4">
            {topProducts.length > 0 ? (
              topProducts.map((product, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium text-gray-900">{product.name}</p>
                    <p className="text-sm text-gray-600">{product.quantity} units in stock</p>
                    <p className="text-xs text-gray-500">{product.category}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-green-600">₹{product.value.toLocaleString()}</p>
                    <p className="text-xs text-gray-500">Total Value</p>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-gray-500 text-center py-4">No products available</p>
            )}
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className={`grid gap-6 ${isMobile ? 'grid-cols-1' : 'grid-cols-2'}`}>
        {/* Recent Activity */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h2 className="text-lg font-semibold text-gray-900 mb-6">Recent Activity</h2>
          <div className="space-y-4">
            {recentActivity.length > 0 ? (
              recentActivity.map((activity, index) => (
                <div key={index} className="flex items-center space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors duration-200">
                  <div className={`w-2 h-2 rounded-full ${
                    activity.action === 'Added' ? 'bg-green-500' :
                    activity.action === 'Updated' ? 'bg-blue-500' : 'bg-red-500'
                  }`}></div>
                  <div className="flex-1">
                    <p className="text-sm">
                      <span className="font-medium">{activity.action}</span> {activity.item}
                    </p>
                    <p className="text-xs text-gray-500">{activity.time}</p>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-gray-500 text-center py-4">No recent activity</p>
            )}
          </div>
        </div>

        {/* Performance Summary */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h2 className="text-lg font-semibold text-gray-900 mb-6">Performance Summary</h2>
          <div className="space-y-4">
            <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
              <span className="font-medium text-green-800">Total Products</span>
              <span className="text-green-600 font-semibold">{products.length}</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
              <span className="font-medium text-blue-800">Total Categories</span>
              <span className="text-blue-600 font-semibold">{categories.length}</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-yellow-50 rounded-lg">
              <span className="font-medium text-yellow-800">Low Stock Alerts</span>
              <span className="text-yellow-600 font-semibold">{lowStockProducts.length}</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-purple-50 rounded-lg">
              <span className="font-medium text-purple-800">Best Category</span>
              <span className="text-purple-600 font-semibold">
                {categoryAnalytics.length > 0 ? categoryAnalytics[0].name : 'N/A'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Reports;
