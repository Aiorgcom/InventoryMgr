
import React, { useState } from 'react';
import { User, Bell, Globe, Shield, HelpCircle, Info, LogOut } from 'lucide-react';
import { useIsMobile } from '@/hooks/use-mobile';
import { useAuth } from '@/hooks/useAuth';
import { useLanguage } from '@/contexts/LanguageContext';
import { toast } from '@/hooks/use-toast';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const Settings = () => {
  const isMobile = useIsMobile();
  const { user, signOut } = useAuth();
  const { t, language, setLanguage } = useLanguage();
  const [isSigningOut, setIsSigningOut] = useState(false);

  const handleSignOut = async () => {
    setIsSigningOut(true);
    try {
      await signOut();
      toast({
        title: t('auth.signedOut'),
        description: t('auth.signOutDesc'),
      });
    } catch (error) {
      toast({
        title: "Error",
        description: t('auth.signOutError'),
        variant: "destructive",
      });
    } finally {
      setIsSigningOut(false);
    }
  };

  const handleLanguageChange = (newLanguage: string) => {
    setLanguage(newLanguage as 'en' | 'hi');
    toast({
      title: "Language Updated",
      description: `Language changed to ${newLanguage === 'en' ? 'English' : 'हिंदी'}`,
    });
  };

  const settingsGroups = [
    {
      title: t('settings.account'),
      icon: User,
      items: [
        { label: t('settings.email'), description: t('settings.emailDesc'), action: user?.email || 'Not available' },
        { label: t('settings.userId'), description: t('settings.userIdDesc'), action: user?.id?.slice(0, 8) + '...' || 'Not available' },
        { label: t('settings.changePassword'), description: t('settings.changePasswordDesc'), action: t('common.comingSoon') }
      ]
    },
    {
      title: t('settings.notifications'),
      icon: Bell,
      items: [
        { label: t('settings.lowStock'), description: t('settings.lowStockDesc'), action: t('common.comingSoon') },
        { label: t('settings.dailyReports'), description: t('settings.dailyReportsDesc'), action: t('common.comingSoon') },
        { label: t('settings.emailNotifications'), description: t('settings.emailNotificationsDesc'), action: t('common.comingSoon') }
      ]
    },
    {
      title: t('settings.language'),
      icon: Globe,
      items: [
        { 
          label: t('settings.languageSelect'), 
          description: t('settings.languageDesc'), 
          action: 'language-select'
        },
        { label: t('settings.currency'), description: t('settings.currencyDesc'), action: 'INR (₹)' },
        { label: t('settings.dateFormat'), description: t('settings.dateFormatDesc'), action: t('common.comingSoon') }
      ]
    },
    {
      title: t('settings.security'),
      icon: Shield,
      items: [
        { label: t('settings.twoFactor'), description: t('settings.twoFactorDesc'), action: t('common.comingSoon') },
        { label: t('settings.loginHistory'), description: t('settings.loginHistoryDesc'), action: t('common.comingSoon') },
        { label: t('settings.dataBackup'), description: t('settings.dataBackupDesc'), action: t('common.comingSoon') }
      ]
    }
  ];

  const supportItems = [
    { label: t('settings.helpCenter'), icon: HelpCircle, description: t('settings.helpCenterDesc') },
    { label: t('settings.contactSupport'), icon: Info, description: t('settings.contactSupportDesc') },
    { label: t('settings.about'), icon: Info, description: t('settings.aboutDesc') }
  ];

  return (
    <div className="space-y-4 md:space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="px-1">
        <h1 className="text-xl md:text-2xl font-bold text-gray-900 mb-1 md:mb-2">{t('settings.title')}</h1>
        <p className="text-sm md:text-base text-gray-600">{t('settings.subtitle')}</p>
      </div>

      {/* Settings Groups */}
      <div className="space-y-4 md:space-y-6">
        {settingsGroups.map((group, groupIndex) => (
          <div key={groupIndex} className="bg-white rounded-lg md:rounded-xl shadow-sm border border-gray-100">
            <div className="p-4 md:p-6 border-b border-gray-100">
              <div className="flex items-center space-x-3">
                <div className="w-7 h-7 md:w-8 md:h-8 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <group.icon className="w-3.5 h-3.5 md:w-4 md:h-4 text-orange-600" />
                </div>
                <h2 className="text-base md:text-lg font-semibold text-gray-900">{group.title}</h2>
              </div>
            </div>
            
            <div className="divide-y divide-gray-100">
              {group.items.map((item, itemIndex) => (
                <div key={itemIndex} className="p-4 md:p-6 hover:bg-gray-50 transition-colors duration-200">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <h3 className="font-medium text-gray-900 mb-1 text-sm md:text-base">{item.label}</h3>
                      <p className="text-xs md:text-sm text-gray-600 leading-relaxed">{item.description}</p>
                    </div>
                    <div className="flex-shrink-0">
                      {item.action === 'language-select' ? (
                        <Select value={language} onValueChange={handleLanguageChange}>
                          <SelectTrigger className="w-full sm:w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="en">{t('lang.english')}</SelectItem>
                            <SelectItem value="hi">{t('lang.hindi')}</SelectItem>
                          </SelectContent>
                        </Select>
                      ) : item.action === t('common.comingSoon') ? (
                        <span className="inline-flex px-2 md:px-3 py-1 text-xs bg-yellow-100 text-yellow-700 rounded-full">
                          {t('common.comingSoon')}
                        </span>
                      ) : item.action.includes('@') || item.action.length > 20 ? (
                        <span className="text-xs md:text-sm text-gray-600 break-all">{item.action}</span>
                      ) : (
                        <span className="text-xs md:text-sm font-medium text-gray-700">{item.action}</span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Support Section */}
      <div className="bg-white rounded-lg md:rounded-xl shadow-sm border border-gray-100">
        <div className="p-4 md:p-6 border-b border-gray-100">
          <h2 className="text-base md:text-lg font-semibold text-gray-900">{t('settings.support')}</h2>
        </div>
        
        <div className="divide-y divide-gray-100">
          {supportItems.map((item, index) => (
            <div key={index} className="p-4 md:p-6 hover:bg-gray-50 transition-colors duration-200 cursor-pointer">
              <div className="flex items-center space-x-3">
                <div className="w-7 h-7 md:w-8 md:h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <item.icon className="w-3.5 h-3.5 md:w-4 md:h-4 text-blue-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-medium text-gray-900 text-sm md:text-base">{item.label}</h3>
                  <p className="text-xs md:text-sm text-gray-600 leading-relaxed">{item.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Sign Out */}
      <div className="bg-white rounded-lg md:rounded-xl shadow-sm border border-gray-100">
        <div className="p-4 md:p-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div className="flex items-center space-x-3 flex-1 min-w-0">
              <div className="w-7 h-7 md:w-8 md:h-8 bg-red-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <LogOut className="w-3.5 h-3.5 md:w-4 md:h-4 text-red-600" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-medium text-gray-900 text-sm md:text-base">{t('auth.signOut')}</h3>
                <p className="text-xs md:text-sm text-gray-600 leading-relaxed">{t('settings.signOutDesc2')}</p>
              </div>
            </div>
            <button
              onClick={handleSignOut}
              disabled={isSigningOut}
              className="w-full sm:w-auto px-4 py-2 bg-red-600 hover:bg-red-700 disabled:bg-red-300 text-white rounded-lg transition-colors duration-200 text-xs md:text-sm font-medium"
            >
              {isSigningOut ? t('auth.signingOut') : t('auth.signOut')}
            </button>
          </div>
        </div>
      </div>

      {/* App Info */}
      <div className="bg-gradient-to-r from-orange-500 to-red-500 rounded-lg md:rounded-xl p-4 md:p-6 text-white">
        <div className="text-center">
          <h3 className="text-lg md:text-xl font-bold mb-2">{t('app.name')}</h3>
          <p className="text-orange-100 mb-3 md:mb-4 text-sm md:text-base">{t('app.tagline')}</p>
          <div className="flex justify-center space-x-4 md:space-x-6 text-xs md:text-sm">
            <span>{t('app.version')}</span>
            <span>•</span>
            <span>{t('app.madeIn')}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;
