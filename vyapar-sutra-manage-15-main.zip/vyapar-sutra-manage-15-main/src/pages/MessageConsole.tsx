
import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { useProducts } from '@/hooks/useProducts';

interface Message {
  id: string;
  type: 'user' | 'bot';
  content: string;
  timestamp: Date;
}

const MessageConsole = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'bot',
      content: 'Hello! I can help you manage your inventory. Try commands like:\n\n• "Add 50 Apples in Fruits at ₹20"\n• "Update Apples to 30"\n• "Show low stock"\n• "Show summary"',
      timestamp: new Date(),
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const { products, categories, addProduct, updateProduct, loading } = useProducts();

  // Auto-scroll to bottom when new messages are added
  useEffect(() => {
    if (scrollAreaRef.current) {
      const scrollElement = scrollAreaRef.current.querySelector('[data-radix-scroll-area-viewport]');
      if (scrollElement) {
        scrollElement.scrollTop = scrollElement.scrollHeight;
      }
    }
  }, [messages]);

  const parseCommand = async (command: string): Promise<string> => {
    const lowerCommand = command.toLowerCase().trim();
    
    // Add product command: "Add [quantity] [product name] in [category] at ₹[price]"
    const addMatch = lowerCommand.match(/add\s+(\d+)\s+(.+?)\s+in\s+(.+?)\s+at\s+₹?(\d+)/);
    if (addMatch) {
      const [, quantity, productName, categoryName, price] = addMatch;
      
      // Find or create category
      let categoryId = categories.find(cat => 
        cat.name.toLowerCase() === categoryName.toLowerCase()
      )?.id;
      
      if (!categoryId) {
        // For simplicity, we'll use the first category or create a default one
        // In a real app, you might want to create the category first
        categoryId = categories[0]?.id || 'default';
      }
      
      try {
        const newProduct = await addProduct({
          name: productName.charAt(0).toUpperCase() + productName.slice(1),
          category_id: categoryId,
          quantity: parseInt(quantity),
          unit: 'units',
          price: parseInt(price),
          low_stock_threshold: 10
        });
        
        return `✅ Successfully added ${quantity} ${productName} in ${categoryName} category at ₹${price} each.\n\nProduct Details:\n• Name: ${newProduct.name}\n• Category: ${categoryName}\n• Quantity: ${quantity}\n• Price: ₹${price}\n• Added to main inventory!`;
      } catch (error) {
        return `❌ Failed to add product. Please try again.`;
      }
    }

    // Update product command: "Update [product name] to [new quantity]"
    const updateMatch = lowerCommand.match(/update\s+(.+?)\s+to\s+(\d+)/);
    if (updateMatch) {
      const [, productName, newQuantity] = updateMatch;
      const product = products.find(p => p.name.toLowerCase() === productName.toLowerCase());
      
      if (product) {
        try {
          await updateProduct(product.id, { quantity: parseInt(newQuantity) });
          return `✅ Successfully updated ${product.name} quantity to ${newQuantity}.\n\nUpdated Details:\n• Product: ${product.name}\n• New Quantity: ${newQuantity}\n• Category: ${categories.find(c => c.id === product.category_id)?.name || 'Unknown'}\n• Price: ₹${product.price}`;
        } catch (error) {
          return `❌ Failed to update product. Please try again.`;
        }
      } else {
        const availableProducts = products.slice(0, 5).map(p => `• ${p.name}`).join('\n');
        return `❌ Product "${productName}" not found in inventory.\n\nSome available products:\n${availableProducts}${products.length > 5 ? '\n• ...' : ''}`;
      }
    }

    // Show low stock command
    if (lowerCommand.includes('show low stock') || lowerCommand.includes('low stock')) {
      const lowStockItems = products.filter(product => product.quantity <= product.low_stock_threshold);
      
      if (lowStockItems.length === 0) {
        return `✅ Great news! No items are running low on stock.\n\nAll products have sufficient quantities.`;
      }
      
      const lowStockList = lowStockItems.map(item => {
        const category = categories.find(c => c.id === item.category_id);
        return `• ${item.name} (${category?.name || 'Unknown'}): ${item.quantity} ${item.unit} remaining (threshold: ${item.low_stock_threshold})`;
      }).join('\n');
      
      return `⚠️ Low Stock Alert!\n\nThe following items need restocking:\n\n${lowStockList}\n\nConsider restocking these items soon.`;
    }

    // Show summary command
    if (lowerCommand.includes('show summary') || lowerCommand.includes('summary')) {
      const totalProducts = products.length;
      const totalValue = products.reduce((sum, product) => sum + (product.quantity * product.price), 0);
      const categorySet = new Set(products.map(p => p.category_id));
      const categoryNames = Array.from(categorySet).map(id => 
        categories.find(c => c.id === id)?.name || 'Unknown'
      );
      const lowStockCount = products.filter(p => p.quantity <= p.low_stock_threshold).length;
      
      const recentProducts = products.slice(0, 10).map(item => {
        const category = categories.find(c => c.id === item.category_id);
        return `• ${item.name}: ${item.quantity} ${item.unit} @ ₹${item.price} each (${category?.name || 'Unknown'})`;
      }).join('\n');
      
      return `📊 Inventory Summary\n\n• Total Products: ${totalProducts}\n• Categories: ${categoryNames.length} (${categoryNames.join(', ')})\n• Total Inventory Value: ₹${totalValue.toLocaleString()}\n• Low Stock Items: ${lowStockCount}\n\n${totalProducts > 0 ? `Recent Stock:\n${recentProducts}${products.length > 10 ? '\n• ...' : ''}` : 'No products in inventory yet.'}`;
    }

    // Default response for unrecognized commands
    return `❓ I didn't understand that command. Here are the available commands:\n\n📝 Add Products:\n• "Add [quantity] [product name] in [category] at ₹[price]"\n• Example: "Add 50 Apples in Fruits at ₹20"\n\n🔄 Update Products:\n• "Update [product name] to [new quantity]"\n• Example: "Update Apples to 30"\n\n📊 Reports:\n• "Show low stock" - View items running low\n• "Show summary" - Complete inventory overview\n\nTry one of these commands!`;
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim() || loading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: inputValue,
      timestamp: new Date(),
    };

    // Add user message
    setMessages(prev => [...prev, userMessage]);

    // Process command and generate bot response
    const response = await parseCommand(inputValue);
    const botMessage: Message = {
      id: (Date.now() + 1).toString(),
      type: 'bot',
      content: response,
      timestamp: new Date(),
    };
    
    setTimeout(() => {
      setMessages(prev => [...prev, botMessage]);
    }, 300);

    setInputValue('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  if (loading) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-600"></div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 p-4 flex items-center space-x-3">
        <div className="w-10 h-10 bg-orange-600 rounded-full flex items-center justify-center">
          <Bot className="w-6 h-6 text-white" />
        </div>
        <div>
          <h2 className="text-lg font-semibold text-gray-900">Inventory Assistant</h2>
          <p className="text-sm text-gray-500">Type commands to manage your inventory</p>
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 p-4">
        <ScrollArea ref={scrollAreaRef} className="h-full">
          <div className="space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`flex space-x-2 max-w-xs lg:max-w-md ${
                    message.type === 'user' ? 'flex-row-reverse space-x-reverse' : ''
                  }`}
                >
                  {/* Avatar */}
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                      message.type === 'user'
                        ? 'bg-blue-600'
                        : 'bg-orange-600'
                    }`}
                  >
                    {message.type === 'user' ? (
                      <User className="w-4 h-4 text-white" />
                    ) : (
                      <Bot className="w-4 h-4 text-white" />
                    )}
                  </div>

                  {/* Message Bubble */}
                  <Card
                    className={`p-3 ${
                      message.type === 'user'
                        ? 'bg-blue-600 text-white'
                        : 'bg-white border-gray-200'
                    }`}
                  >
                    <div className="whitespace-pre-wrap text-sm">
                      {message.content}
                    </div>
                    <div
                      className={`text-xs mt-1 ${
                        message.type === 'user' ? 'text-blue-100' : 'text-gray-500'
                      }`}
                    >
                      {formatTime(message.timestamp)}
                    </div>
                  </Card>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </div>

      {/* Input Area */}
      <div className="bg-white border-t border-gray-200 p-4">
        <div className="flex space-x-2">
          <Input
            placeholder="Type a command... (e.g., Add 50 Apples in Fruits at ₹20)"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={handleKeyPress}
            className="flex-1"
            disabled={loading}
          />
          <Button
            onClick={handleSendMessage}
            disabled={!inputValue.trim() || loading}
            size="icon"
            className="bg-orange-600 hover:bg-orange-700"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
        
        {/* Command Examples */}
        <div className="mt-2 text-xs text-gray-500">
          <span className="font-medium">Examples:</span> "Add 100 Rice in Grains at ₹50" • "Update Rice to 75" • "Show low stock"
        </div>
      </div>
    </div>
  );
};

export default MessageConsole;
