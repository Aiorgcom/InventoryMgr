
import React, { createContext, useContext, useState, useEffect } from 'react';

type Language = 'en' | 'hi';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

// Translation data
const translations = {
  en: {
    // Navigation
    'nav.home': 'Home',
    'nav.inventory': 'Inventory',
    'nav.chat': 'Chat',
    'nav.reports': 'Reports',
    'nav.settings': 'Settings',
    
    // Common
    'common.save': 'Save',
    'common.cancel': 'Cancel',
    'common.update': 'Update',
    'common.delete': 'Delete',
    'common.edit': 'Edit',
    'common.add': 'Add',
    'common.search': 'Search',
    'common.loading': 'Loading...',
    'common.comingSoon': 'Coming Soon',
    
    // Auth
    'auth.signOut': 'Sign Out',
    'auth.account': 'Account',
    'auth.signingOut': 'Signing out...',
    'auth.signedOut': 'Signed out successfully',
    'auth.signOutDesc': 'You have been logged out of your account.',
    'auth.signOutError': 'Failed to sign out. Please try again.',
    
    // Settings
    'settings.title': 'Settings',
    'settings.subtitle': 'Manage your account and app preferences',
    'settings.account': 'Account',
    'settings.notifications': 'Notifications',
    'settings.language': 'Language & Region',
    'settings.security': 'Security',
    'settings.support': 'Support & Information',
    
    // Settings - Account
    'settings.email': 'Email',
    'settings.emailDesc': 'Your account email address',
    'settings.userId': 'User ID',
    'settings.userIdDesc': 'Your unique user identifier',
    'settings.changePassword': 'Change Password',
    'settings.changePasswordDesc': 'Update your login credentials',
    
    // Settings - Notifications
    'settings.lowStock': 'Low Stock Alerts',
    'settings.lowStockDesc': 'Get notified when items are running low',
    'settings.dailyReports': 'Daily Reports',
    'settings.dailyReportsDesc': 'Receive daily business summaries',
    'settings.emailNotifications': 'Email Notifications',
    'settings.emailNotificationsDesc': 'Manage your email preferences',
    
    // Settings - Language
    'settings.languageSelect': 'Language',
    'settings.languageDesc': 'Choose your preferred language',
    'settings.currency': 'Currency',
    'settings.currencyDesc': 'Set your business currency',
    'settings.dateFormat': 'Date Format',
    'settings.dateFormatDesc': 'Select date display format',
    
    // Settings - Security
    'settings.twoFactor': 'Two-Factor Authentication',
    'settings.twoFactorDesc': 'Add extra security to your account',
    'settings.loginHistory': 'Login History',
    'settings.loginHistoryDesc': 'View recent login activity',
    'settings.dataBackup': 'Data Backup',
    'settings.dataBackupDesc': 'Backup your inventory data',
    
    // Settings - Support
    'settings.helpCenter': 'Help Center',
    'settings.helpCenterDesc': 'Find answers to common questions',
    'settings.contactSupport': 'Contact Support',
    'settings.contactSupportDesc': 'Get help from our support team',
    'settings.about': 'About',
    'settings.aboutDesc': 'Learn more about StockMaster',
    'settings.signOutDesc2': 'Sign out of your account',
    
    // App Info
    'app.name': 'StockMaster',
    'app.tagline': 'Inventory Management for Indian Businesses',
    'app.version': 'Version 1.0.0',
    'app.madeIn': 'Made with ❤️ in India',
    
    // Languages
    'lang.english': 'English',
    'lang.hindi': 'हिंदी',
  },
  hi: {
    // Navigation
    'nav.home': 'होम',
    'nav.inventory': 'इन्वेंटरी',
    'nav.chat': 'चैट',
    'nav.reports': 'रिपोर्ट',
    'nav.settings': 'सेटिंग्स',
    
    // Common
    'common.save': 'सेव करें',
    'common.cancel': 'रद्द करें',
    'common.update': 'अपडेट करें',
    'common.delete': 'डिलीट करें',
    'common.edit': 'एडिट करें',
    'common.add': 'जोड़ें',
    'common.search': 'खोजें',
    'common.loading': 'लोड हो रहा है...',
    'common.comingSoon': 'जल्द आ रहा है',
    
    // Auth
    'auth.signOut': 'साइन आउट',
    'auth.account': 'खाता',
    'auth.signingOut': 'साइन आउट हो रहे हैं...',
    'auth.signedOut': 'सफलतापूर्वक साइन आउट हो गए',
    'auth.signOutDesc': 'आप अपने खाते से लॉग आउट हो गए हैं।',
    'auth.signOutError': 'साइन आउट नहीं हो सका। कृपया पुनः प्रयास करें।',
    
    // Settings
    'settings.title': 'सेटिंग्स',
    'settings.subtitle': 'अपने खाते और ऐप की प्राथमिकताओं को प्रबंधित करें',
    'settings.account': 'खाता',
    'settings.notifications': 'नोटिफिकेशन',
    'settings.language': 'भाषा और क्षेत्र',
    'settings.security': 'सिक्योरिटी',
    'settings.support': 'सहायता और जानकारी',
    
    // Settings - Account
    'settings.email': 'ईमेल',
    'settings.emailDesc': 'आपके खाते का ईमेल पता',
    'settings.userId': 'यूजर आईडी',
    'settings.userIdDesc': 'आपकी विशिष्ट उपयोगकर्ता पहचान',
    'settings.changePassword': 'पासवर्ड बदलें',
    'settings.changePasswordDesc': 'अपने लॉगिन क्रेडेंशियल अपडेट करें',
    
    // Settings - Notifications
    'settings.lowStock': 'कम स्टॉक अलर्ट',
    'settings.lowStockDesc': 'जब आइटम कम हो जाएं तो सूचना पाएं',
    'settings.dailyReports': 'दैनिक रिपोर्ट',
    'settings.dailyReportsDesc': 'दैनिक व्यापार सारांश प्राप्त करें',
    'settings.emailNotifications': 'ईमेल नोटिफिकेशन',
    'settings.emailNotificationsDesc': 'अपनी ईमेल प्राथमिकताएं प्रबंधित करें',
    
    // Settings - Language
    'settings.languageSelect': 'भाषा',
    'settings.languageDesc': 'अपनी पसंदीदा भाषा चुनें',
    'settings.currency': 'मुद्रा',
    'settings.currencyDesc': 'अपना व्यापारिक मुद्रा सेट करें',
    'settings.dateFormat': 'तारीख प्रारूप',
    'settings.dateFormatDesc': 'तारीख प्रदर्शन प्रारूप चुनें',
    
    // Settings - Security
    'settings.twoFactor': 'द्विकारक प्रमाणीकरण',
    'settings.twoFactorDesc': 'अपने खाते में अतिरिक्त सुरक्षा जोड़ें',
    'settings.loginHistory': 'लॉगिन इतिहास',
    'settings.loginHistoryDesc': 'हाल की लॉगिन गतिविधि देखें',
    'settings.dataBackup': 'डेटा बैकअप',
    'settings.dataBackupDesc': 'अपने इन्वेंटरी डेटा का बैकअप लें',
    
    // Settings - Support
    'settings.helpCenter': 'सहायता केंद्र',
    'settings.helpCenterDesc': 'सामान्य प्रश्नों के उत्तर खोजें',
    'settings.contactSupport': 'सहायता से संपर्क करें',
    'settings.contactSupportDesc': 'हमारी सहायता टीम से सहायता प्राप्त करें',
    'settings.about': 'हमारे बारे में',
    'settings.aboutDesc': 'StockMaster के बारे में और जानें',
    'settings.signOutDesc2': 'अपने खाते से साइन आउट करें',
    
    // App Info
    'app.name': 'StockMaster',
    'app.tagline': 'भारतीय व्यापार के लिए इन्वेंटरी प्रबंधन',
    'app.version': 'संस्करण 1.0.0',
    'app.madeIn': 'भारत में ❤️ के साथ बनाया गया',
    
    // Languages
    'lang.english': 'English',
    'lang.hindi': 'हिंदी',
  }
};

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>(() => {
    const saved = localStorage.getItem('app-language');
    return (saved as Language) || 'en';
  });

  useEffect(() => {
    localStorage.setItem('app-language', language);
  }, [language]);

  const t = (key: string): string => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
