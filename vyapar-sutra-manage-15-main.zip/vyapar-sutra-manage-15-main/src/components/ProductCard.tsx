
import React from 'react';
import { Edit, Trash2, AlertTriangle } from 'lucide-react';

interface Product {
  id: string;
  name: string;
  category: string;
  quantity: number;
  unit: string;
  price: number;
  lowStock?: boolean;
}

interface ProductCardProps {
  product: Product;
  onEdit: (product: Product) => void;
  onDelete: (id: string) => void;
}

const ProductCard = ({ product, onEdit, onDelete }: ProductCardProps) => {
  return (
    <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100 hover:shadow-md transition-shadow duration-200">
      <div className="flex justify-between items-start mb-3">
        <div className="flex-1">
          <h3 className="font-semibold text-gray-900 mb-1">{product.name}</h3>
          <p className="text-sm text-gray-500 mb-2">{product.category}</p>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center">
              <span className={`font-medium ${product.lowStock ? 'text-red-600' : 'text-gray-900'}`}>
                {product.quantity} {product.unit}
              </span>
              {product.lowStock && (
                <AlertTriangle className="w-4 h-4 text-red-500 ml-1" />
              )}
            </div>
            <span className="text-green-600 font-semibold">₹{product.price}</span>
          </div>
        </div>
        
        <div className="flex space-x-2">
          <button
            onClick={() => onEdit(product)}
            className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors duration-200"
          >
            <Edit className="w-4 h-4" />
          </button>
          <button
            onClick={() => onDelete(product.id)}
            className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors duration-200"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>
      
      {product.lowStock && (
        <div className="bg-red-50 text-red-700 text-xs px-3 py-1 rounded-full inline-block">
          Low Stock Alert
        </div>
      )}
    </div>
  );
};

export default ProductCard;
